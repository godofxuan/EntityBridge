"""Local company identity API and three server-rendered governance pages."""

from __future__ import annotations

import csv
import io
import secrets
from pathlib import Path
from typing import Literal
from urllib.parse import urlsplit

from fastapi import Depends, FastAPI, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, ConfigDict, Field

from .candidates import BLOCKING_VERSION, generate_candidates
from .matching import score_baselines
from .normalization import FEATURE_VIEW_VERSION, NORMALIZATION_VERSION, matcher_view
from .store import Store, VersionConflict, digest


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class RelatedEntity(StrictModel):
    kind: Literal["branch_of", "successor_of"]
    target_source: str = Field(min_length=1, max_length=80)
    target_key: str = Field(min_length=1, max_length=200)
    evidence: str = Field(min_length=1, max_length=2000)


class SourceRow(StrictModel):
    source_key: str = Field(min_length=1, max_length=200)
    name: str = Field(min_length=1, max_length=500)
    address: str | None = Field(None, max_length=1000)
    city: str | None = Field(None, max_length=200)
    postcode: str | None = Field(None, max_length=40)
    country: str | None = Field(None, max_length=10)
    aliases: list[str] = Field(default_factory=list, max_length=30)
    registration_authority: str | None = Field(None, max_length=30)
    registration_number: str | None = Field(None, max_length=50)
    lei: str | None = Field(None, max_length=20)
    category: str | None = Field(None, max_length=30)
    status: str | None = Field(None, max_length=50)
    registration_status: str | None = Field(None, max_length=30)
    relationships: list[RelatedEntity] = Field(default_factory=list, max_length=30)
    tombstone: bool = False


class ImportRequest(StrictModel):
    source: str = Field(min_length=1, max_length=80, pattern=r"^[a-zA-Z0-9_-]+$")
    rows: list[SourceRow] = Field(min_length=1, max_length=10000)


class RunRequest(StrictModel):
    method: Literal["exact", "fuzzy", "splink"] = "splink"
    threshold: float = Field(default=0.9, ge=0, le=1)
    review_threshold: float = Field(default=0.5, ge=0, le=1)
    incremental: bool = True
    verify_full: bool = False


class PublishRequest(StrictModel):
    expected_parent: str | None


class DecisionRequest(StrictModel):
    left: str
    right: str
    action: Literal["accept", "reject", "abstain"]
    reason: str = Field(min_length=1, max_length=2000)
    base_revision: str
    left_version: str
    right_version: str
    policy_version: str


class RevokeRequest(StrictModel):
    base_revision: str
    reason: str = Field(default="Revocation preview", min_length=1, max_length=2000)
    preview_cutoff: int | None = Field(default=None, ge=0)


def run_matching(store, settings, model_path=None):
    raw = store.active_records()
    records = [matcher_view(row, key, row["record_version_id"]) for key, row in raw.items()]
    if settings.method == "splink":
        if not model_path:
            raise ValueError("A frozen trained model must be configured before a Splink run")
        from .matching import SplinkMatcher
        model = SplinkMatcher.load(model_path)
        score = model.score
        model_version = model.fingerprint
    else:
        score = lambda rows, pairs: score_baselines(rows, pairs)[settings.method]
        model_version = settings.method + "-name-v1"
    policy = digest({"model": model_version, "threshold": settings.threshold,
        "normalization": NORMALIZATION_VERSION, "feature_view": FEATURE_VIEW_VERSION,
        "review_threshold": settings.review_threshold, "blocking": BLOCKING_VERSION, "resolver": "greedy-v1"})
    parent = store.current_revision()
    previous = store._payload(parent) if parent else None
    refresh = None
    if settings.incremental and previous and previous["policy_version"] == policy:
        from .incremental import refresh_scores
        old_records = [matcher_view(row, key, row["record_version_id"]) for key, row in previous["records"].items()]
        edges, refresh = refresh_scores(old_records, records, previous["edges"], score)
        if settings.verify_full:
            complete = score(records, generate_candidates(records))
            as_map = lambda items: {(edge["left"], edge["right"]): edge["score"] for edge in items}
            a, b = as_map(edges), as_map(complete)
            if a.keys() != b.keys() or any(abs(a[pair] - b[pair]) > 1e-12 for pair in a):
                raise RuntimeError("Incremental scores differ from full scoring")
    else:
        candidates = generate_candidates(records)
        edges = score(records, candidates)
    candidate = store.prepare_revision(edges, policy_version=policy, threshold=settings.threshold,
        review_threshold=settings.review_threshold, expected_input_hash=digest(raw), verify_full=settings.verify_full)
    return {**candidate, "candidate_pairs": len(edges), "records": len(records), "method": settings.method,
            "score_refresh": refresh}


def create_app(store: Store, *, tokens=None, model_path=None, local_demo=False):
    app = FastAPI(title="EntityBridge", version="0.1.0")
    tokens = tokens or {}
    templates = Jinja2Templates(directory=str(Path(__file__).parent / "web/templates"))
    app.mount("/static", StaticFiles(directory=str(Path(__file__).parent / "web/static")), name="static")

    @app.middleware("http")
    async def guard(request: Request, call_next):
        hosts = {"127.0.0.1", "localhost", "::1"}
        if request.client and request.client.host == "testclient":
            hosts.add("testserver")
        if urlsplit("http://" + request.headers.get("host", "")).hostname not in hosts:
            return JSONResponse({"detail": "Untrusted Host"}, status_code=400)
        if request.method not in {"GET", "HEAD", "OPTIONS"}:
            origin = request.headers.get("origin")
            if origin and urlsplit(origin).netloc != request.headers.get("host"):
                return JSONResponse({"detail": "Cross-origin writes are not allowed"}, status_code=403)
            data = bytearray()
            async for chunk in request.stream():
                data.extend(chunk)
                if len(data) > 5 * 1024 * 1024:
                    return JSONResponse({"detail": "Request exceeds 5 MiB"}, status_code=413)
            request._body = bytes(data)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self'; script-src 'self'; frame-ancestors 'none'"
        return response

    def actor(request: Request):
        if local_demo and request.client and request.client.host in {"127.0.0.1", "::1", "testclient"}:
            return ("local-demo", "admin")
        token = request.headers.get("authorization", "").removeprefix("Bearer ") or request.cookies.get("eb_session", "")
        found = next((identity for key, identity in tokens.items() if secrets.compare_digest(token, key)), None)
        if not found:
            raise HTTPException(401, "Sign in or supply a valid bearer token")
        return found

    def admin(identity=Depends(actor)):
        if identity[1] != "admin":
            raise HTTPException(403, "Administrator permission required")
        return identity

    @app.exception_handler(VersionConflict)
    async def conflict(request, exc):
        if request.url.path.startswith("/ui/"):
            return templates.TemplateResponse(request=request, name="app.html", status_code=409,
                context={"page": "error", "revision": store.current_revision(), "demo": local_demo,
                         "message": "依据版本已变化，请回到版本页刷新后重新操作。", "detail": str(exc)})
        return JSONResponse({"detail": str(exc), "current_revision": store.current_revision()}, status_code=409)

    @app.exception_handler(ValueError)
    async def invalid(_request, exc):
        return JSONResponse({"detail": str(exc)}, status_code=422)

    @app.exception_handler(KeyError)
    async def missing(_request, _exc):
        return JSONResponse({"detail": "Resource not found"}, status_code=404)

    @app.post("/imports")
    def import_records(body: ImportRequest, _identity=Depends(admin)):
        return store.import_records(body.source, [row.model_dump(exclude_none=True) for row in body.rows])

    @app.post("/match-runs")
    def match_run(body: RunRequest, _identity=Depends(admin)):
        return run_matching(store, body, model_path)

    @app.post("/registry-runs")
    def registry_run(_identity=Depends(admin)):
        from .identifier_rich import trusted_registry_edges
        raw = store.active_records()
        result = trusted_registry_edges(raw.values())
        candidate = store.prepare_revision(result["edges"], policy_version="identifier-rich-RA000585-v1",
            threshold=1.0, review_threshold=1.0, expected_input_hash=digest(raw))
        return {**candidate, "mode": "identifier-rich", "candidate_pairs": len(result["edges"]),
                "conflicts": result["conflicts"], "excluded_record_ids": result["excluded_record_ids"]}

    @app.get("/entities")
    def entities(query: str = "", revision: str | None = None):
        return store.entities(query, revision=revision)

    @app.get("/entities/{entity_id}")
    def entity(entity_id: str, revision: str | None = None):
        return store.entity(entity_id, revision=revision)

    @app.get("/records/{record_id}/links")
    def links(record_id: str):
        current = store.current_revision()
        if not current:
            raise KeyError(record_id)
        payload = store._payload(current)
        if record_id not in payload["records"]:
            raise KeyError(record_id)
        return {"revision_id": current, "record": payload["records"][record_id],
            "links": [edge for edge in payload["edges"] if record_id in (edge["left"], edge["right"])]}

    @app.post("/reviews/decision")
    def decide(body: DecisionRequest, identity=Depends(actor)):
        return store.decide(**body.model_dump(), reviewer=identity[0])

    @app.post("/decisions/{decision_id}/revoke-preview")
    def revoke_preview(decision_id: str, body: RevokeRequest, _identity=Depends(actor)):
        return store.revoke_preview(decision_id, base_revision=body.base_revision)

    @app.post("/decisions/{decision_id}/revoke")
    def revoke(decision_id: str, body: RevokeRequest, identity=Depends(actor)):
        if body.preview_cutoff is None:
            raise ValueError("Confirm the exact preview_cutoff shown by revoke-preview")
        return store.revoke(decision_id, **body.model_dump(), reviewer=identity[0])

    @app.post("/revisions/{revision_id}/publish")
    def publish(revision_id: str, body: PublishRequest, _identity=Depends(admin)):
        return store.publish(revision_id, **body.model_dump())

    @app.get("/exports")
    def export(revision: str):
        payload = store._payload(revision)
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["revision_id", "entity_id", "record_id", "record_version_id", "source", "name", "canonical_name_source_version"])
        for entity in payload["entities"].values():
            for member in entity["members"]:
                row = payload["records"][member]
                # Prevent formula interpretation when a consumer opens CSV in a spreadsheet.
                name = row.get("name", "")
                if name.startswith(("=", "+", "-", "@", "\t", "\r")):
                    name = "'" + name
                writer.writerow([revision, entity["entity_id"], member, row["record_version_id"], row["source"], name,
                    entity["canonical"].get("name", {}).get("record_version_id", "")])
        return Response(output.getvalue(), media_type="text/csv",
            headers={"Content-Disposition": f'attachment; filename="entities-{revision}.csv"'})

    def render(request, page, **context):
        labels = {"active": "当前身份", "historical": "历史身份", "retired": "身份已变更",
            "accepted": "已接纳", "review": "待复核", "conflict": "约束冲突", "suppressed": "已抑制",
            "below_threshold": "依据不足", "prepared": "待发布", "published": "已发布",
            "accept": "确认同一企业", "reject": "判定不同", "abstain": "暂缓", "CREATE": "建立判断",
            "REVOKE": "撤销判断", "EXPIRE": "依据已过期", "name": "企业名称", "address": "地址",
            "city": "城市", "postcode": "邮编", "country": "国家",
            "score_at_or_above_threshold": "评分达到自动接纳阈值。", "explicit_must_link": "人工确认同一企业。",
            "score_in_review_band": "评分处于待复核区间。", "cluster_cannot_link": "归并会违反企业簇内的不同企业判断。",
            "revoked_basis_requires_review": "此依据已被撤销或暂缓，需要重新复核。",
            "insufficient_score_not_a_cannot_link": "当前依据不足以归并；不代表已判定为不同企业。"}
        return templates.TemplateResponse(request=request, name="app.html", context={"page": page,
            "revision": store.current_revision(), "demo": local_demo, "labels": labels, **context})

    @app.get("/", response_class=HTMLResponse)
    def home(request: Request, query: str = ""):
        all_entities = store.entities(query)
        return render(request, "entities", entities=all_entities[:100], total=len(all_entities), query=query)

    @app.get("/entity/{entity_id}", response_class=HTMLResponse)
    def detail(request: Request, entity_id: str, revision: str | None = None):
        return render(request, "detail", entity=store.entity(entity_id, revision=revision))

    @app.get("/reviews", response_class=HTMLResponse)
    def reviews(request: Request):
        current = store.current_revision()
        payload = store._payload(current) if current else None
        queue = []
        if payload:
            evidence = {tuple(sorted((edge["left"], edge["right"]))): edge for edge in payload["edges"]}
            for decision in payload["edge_decisions"]:
                if decision["score"] is None:
                    continue
                pair = tuple(sorted((decision["left"], decision["right"])))
                queue.append({**decision, "left_record": payload["records"][decision["left"]],
                    "right_record": payload["records"][decision["right"]], "evidence": evidence[pair].get("evidence", {})})
            queue.sort(key=lambda row: (row["status"] == "accepted", abs(row["score"] - 0.5)))
        return render(request, "reviews", queue=queue[:100], total=len(queue), payload=payload)

    @app.get("/history", response_class=HTMLResponse)
    def history(request: Request):
        return render(request, "history", history=store.history(), decisions=store.decision_history())

    @app.post("/ui/login")
    def login(token: str = Form()):
        if token not in tokens:
            raise HTTPException(401, "Invalid token")
        response = RedirectResponse("/reviews", status_code=303)
        response.set_cookie("eb_session", token, httponly=True, samesite="strict", max_age=3600)
        return response

    @app.post("/ui/decision")
    def ui_decision(left: str = Form(), right: str = Form(), action: str = Form(), reason: str = Form(),
                    base_revision: str = Form(), left_version: str = Form(), right_version: str = Form(),
                    policy_version: str = Form(), identity=Depends(actor)):
        store.decide(left, right, action=action, reason=reason, reviewer=identity[0], base_revision=base_revision,
            left_version=left_version, right_version=right_version, policy_version=policy_version)
        return RedirectResponse("/history", status_code=303)

    @app.post("/ui/publish")
    def ui_publish(revision_id: str = Form(), expected_parent: str = Form(""), _identity=Depends(admin)):
        store.publish(revision_id, expected_parent=expected_parent or None)
        return RedirectResponse("/history", status_code=303)

    @app.post("/ui/revoke-preview", response_class=HTMLResponse)
    def ui_preview(request: Request, decision_id: str = Form(), base_revision: str = Form(), _identity=Depends(actor)):
        preview = store.revoke_preview(decision_id, base_revision=base_revision)
        records = store._payload(base_revision)["records"]
        groups = [[records[record] for record in group] for group in preview["partitions"]]
        return render(request, "preview", preview=preview, groups=groups)

    @app.post("/ui/revoke")
    def ui_revoke(decision_id: str = Form(), base_revision: str = Form(), reason: str = Form(),
                  preview_cutoff: int = Form(), identity=Depends(actor)):
        store.revoke(decision_id, base_revision=base_revision, reason=reason, reviewer=identity[0], preview_cutoff=preview_cutoff)
        return RedirectResponse("/history", status_code=303)

    @app.get("/health")
    def health():
        return {"status": "ok", "revision": store.current_revision()}

    return app
