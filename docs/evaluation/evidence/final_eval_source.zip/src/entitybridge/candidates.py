"""Fixed, enumerable cross-source blocking. No learned frequencies or truncation."""
from collections import defaultdict
from itertools import combinations, product

FEATURE_COLUMNS = frozenset({"record_id", "record_version_id", "source", "name",
                             "address", "city", "postcode", "country"})
BLOCKING_VERSION = "fixed-union-v2-missing-country"


class CandidateOverflow(ValueError):
    """The declared complete candidate set exceeds the configured bucket budget."""


def validate_records(records):
    records = list(records)
    seen = set()
    for record in records:
        if set(record) - FEATURE_COLUMNS:
            raise ValueError("Matcher input contains columns outside the identifier-missing allowlist")
        if not record.get("record_id") or record["record_id"] in seen:
            raise ValueError("record_id must be non-empty and unique")
        if not record.get("source"):
            raise ValueError("source is required")
        seen.add(record["record_id"])
    return records


def bucket_keys(record):
    """Return stable keys determined by this record alone (usable by incremental)."""
    name = record.get("name") or ""
    postcode = record.get("postcode") or ""
    address = record.get("address") or ""
    keys = set()
    if name:
        keys.add(("name_exact", name))
        if len(name) >= 8:
            keys.add(("name_prefix8", name[:8]))
        if postcode:
            keys.add(("postcode_name_prefix3", postcode, name[:3]))
    if address and postcode:
        keys.add(("address_exact", postcode, address))
    return keys


def generate_candidates(records, *, max_bucket_pairs=250_000):
    records = validate_records(records)
    buckets = defaultdict(list)
    for record in records:
        for key in bucket_keys(record):
            buckets[key].append(record)
    pairs = {}
    for key in sorted(buckets):
        bucket = buckets[key]
        source_counts = defaultdict(int)
        for record in bucket:
            source_counts[record["source"]] += 1
        size = sum(a * b for a, b in combinations(source_counts.values(), 2))
        if size > max_bucket_pairs:
            raise CandidateOverflow(f"{key[0]} bucket has {size} cross-source pairs; limit={max_bucket_pairs}")
        by_source = defaultdict(list)
        for record in bucket:
            by_source[record["source"]].append(record)
        for source_a, source_b in combinations(by_source.values(), 2):
            for a, b in product(source_a, source_b):
                if a.get("country") and b.get("country") and a["country"] != b["country"]:
                    continue
                left, right = sorted((a["record_id"], b["record_id"]))
                pair = pairs.setdefault((left, right), {"left": left, "right": right, "rules": set()})
                pair["rules"].add(key[0])
    return [{**pairs[key], "rules": sorted(pairs[key]["rules"])} for key in sorted(pairs)]
