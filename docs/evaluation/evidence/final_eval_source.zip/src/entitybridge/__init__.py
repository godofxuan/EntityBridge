"""EntityBridge: traceable company matching and reversible identity resolution."""

__version__ = "0.1.0"
