# Frozen training source

Original source hashes are in the accompanying plan.json. The unchanged upstream Apache-2.0 license has been included for distribution. The release changed these files after the snapshot: pyproject.toml. No neural scoring/training implementation changed.
