"""Compare frozen scorers on entity-disjoint, partially labelled public benchmarks.

No unseen pair is invented as a negative. Retrieval and supplied-pair classification
are separate tracks. All thresholds are selected using validation labels only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
import time
import zipfile
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import psutil
import pyarrow.parquet as pq

from entitybridge.benchmark_metrics import (
    evaluate_labeled_pairs,
    group_bootstrap_intervals,
    review_budget_curve,
    select_cost_threshold,
)
from entitybridge.candidates import FrozenNameRetriever, generate_candidates
from entitybridge.matching import SplinkMatcher, score_baselines
from entitybridge.supervised import FrozenPairClassifier


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pairs(items):
    return {tuple(sorted((item["left"], item["right"]))) for item in items}


def label_pairs(labels):
    return {tuple(sorted((item["left_id"], item["right_id"]))) for item in labels}


def build_candidate_tracks(records, labels, retriever):
    fixed = generate_candidates(records)
    hybrid = generate_candidates(records, retriever=retriever)
    supplied = [{"left": left, "right": right, "rules": ["supplied_labelled_pair_diagnostic"]}
                for left, right in sorted(label_pairs(labels))]
    return {"fixed": fixed, "hybrid": hybrid, "supplied_pairs_only": supplied}


def score_tracks(records, tracks, trained):
    union = {}
    for candidates in tracks.values():
        for candidate in candidates:
            union.setdefault((candidate["left"], candidate["right"]), candidate)
    candidates = [union[pair] for pair in sorted(union)]
    output = score_baselines(records, candidates)
    for method, model in trained.items():
        output[method] = model.score(records, candidates)
    return {method: {tuple(sorted((item["left"], item["right"]))): item["score"] for item in edges}
            for method, edges in output.items()}


def run(dataset, output, *, false_positive_cost=10.0, false_negative_cost=1.0, bootstrap=400):
    from entitybridge.benchmarks import verify_benchmark

    if output.exists():
        raise ValueError("Use a fresh output directory; frozen runs cannot be overwritten")
    verification = verify_benchmark(dataset)
    output.mkdir(parents=True)
    started = time.perf_counter()
    stages, failures = {}, {}

    def timed(name, action):
        begin = time.perf_counter()
        result = action()
        stages[name] = time.perf_counter() - begin
        return result

    def read(split):
        records = pq.read_table(dataset / "matcher" / f"{split}.parquet").to_pylist()
        labels = pq.read_table(dataset / "evaluator/labelled_pairs.parquet", filters=[("split", "=", split)]).to_pylist()
        return records, labels

    save(output / "input_verification.json", verification)
    source_files = [ROOT / "src/entitybridge" / name for name in
                    ("candidates.py", "matching.py", "normalization.py", "supervised.py", "benchmark_metrics.py", "benchmarks.py")]
    source_files.append(Path(__file__).resolve())
    with zipfile.ZipFile(output / "evaluation_source.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for file in source_files:
            archive.write(file, file.relative_to(ROOT).as_posix())
    save(output / "protocol.json", {
        "written_at": datetime.now(UTC).isoformat(), "test_evaluated": False,
        "methods": ["exact", "fuzzy", "splink", "supervised_logistic"],
        "tracks": ["fixed", "hybrid", "supplied_pairs_only"],
        "candidate_settings": {"top_k": 10, "min_similarity": 0.2, "fit_split": "train"},
        "selection": "Minimum labelled validation FP/FN cost; reject-all is an explicit option",
        "costs": {"false_positive": false_positive_cost, "false_negative": false_negative_cost},
        "bootstrap": {"replicates": bootstrap, "seed": 20260912, "group": "connected explicitly labelled-pair components"},
        "unknown_pairs": "Unknown; never implicit negatives or complete cluster truth",
        "supplied_pairs_track": "Diagnostic pair classification; candidate set supplied by benchmark, not production retrieval",
        "source_files": {file.relative_to(ROOT).as_posix(): sha(file) for file in source_files},
        "source_archive_sha256": sha(output / "evaluation_source.zip"),
        "dataset_manifest_sha256": sha(dataset / "manifest.json"), "requirements_sha256": sha(ROOT / "requirements.lock"),
    })
    try:
        train, train_labels = read("train")
        validation, validation_labels = read("validation")
        retriever = timed("fit_retriever", lambda: FrozenNameRetriever.fit(train, top_k=10, min_similarity=0.2))
        retriever.save(output / "candidate_model")
        trained = {}
        for method, fit in [("splink", lambda: SplinkMatcher.fit(train)),
                            ("supervised_logistic", lambda: FrozenPairClassifier.fit(train, train_labels))]:
            try:
                trained[method] = timed(f"fit_{method}", fit)
                trained[method].save(output / method)
            except ValueError as error:
                failures[method] = {"stage": "train", "type": type(error).__name__, "reason": str(error)}
        val_tracks = timed("validation_candidates", lambda: build_candidate_tracks(validation, validation_labels, retriever))
        val_scores = timed("validation_scores", lambda: score_tracks(validation, val_tracks, trained))
        selections = {}
        for track, candidates in val_tracks.items():
            candidate_set = pairs(candidates)
            selections[track] = {}
            for method, scores in val_scores.items():
                values = {pair: scores[pair] for pair in candidate_set}
                selections[track][method] = select_cost_threshold(
                    validation_labels, candidate_set, values, split="validation",
                    false_positive_cost=false_positive_cost, false_negative_cost=false_negative_cost,
                    thresholds=sorted({values[pair] for pair in values.keys() & label_pairs(validation_labels)}),
                    return_curve=True)
                if selections[track][method]["status"] != "selected":
                    raise ValueError("Validation needs both label classes before selecting a test decision policy")
        frozen = {"thresholds": selections, "failures": failures,
                  "models": {method: model.fingerprint for method, model in trained.items()},
                  "candidate_model": retriever.fingerprint, "test_features_read_after_this_file": True,
                  "freeze_written_at": datetime.now(UTC).isoformat(),
                  "model_metadata": {method: (model.training_metadata if method == "splink" else model.metadata)
                                     for method, model in trained.items()}}
        save(output / "frozen_config.json", frozen)
        # Test is first scored here, after train/validation choices are on disk.
        test, test_labels = read("test")
        tracks = timed("test_candidates", lambda: build_candidate_tracks(test, test_labels, retriever))
        scores = timed("test_scores", lambda: score_tracks(test, tracks, trained))
        source_counts = Counter(row["source"] for row in test)
        if len(source_counts) != 2:
            raise ValueError("Benchmark pair universe requires exactly two test sources")
        a, b = source_counts.values()
        results = {}
        budgets = sorted({0, 10, 25, 50, 100, 250, 500})
        for track, candidates in tracks.items():
            candidate_set = pairs(candidates)
            results[track] = {}
            for method, all_scores in scores.items():
                values = {pair: all_scores[pair] for pair in candidate_set}
                selected = selections[track][method]
                threshold = selected["selected_threshold"]
                metric = evaluate_labeled_pairs(
                    test_labels, candidate_set, values, threshold=threshold, universe_pair_count=a * b,
                    score_kind="probability" if method in trained else "similarity")
                metric["validation_selection_status"] = selected["status"]
                metric["review_budget"] = review_budget_curve(test_labels, values, budgets)
                metric["group_bootstrap"] = group_bootstrap_intervals(
                    test_labels, candidate_set, values, threshold=threshold, n_resamples=bootstrap, seed=20260912)
                metric["test_cost"] = (false_positive_cost * metric["end_to_end"]["fp"]
                                       + false_negative_cost * metric["end_to_end"]["fn"])
                results[track][method] = metric
        save(output / "scores.json", {method: [[*pair, value] for pair, value in sorted(values.items())]
                                       for method, values in scores.items()})
        report = {"benchmark": json.loads((dataset / "manifest.json").read_text(encoding="utf-8"))["dataset"],
                  "protocol": "known-entity-disjoint-partial-labels-v1", "test_status": "first-predeclared-benchmark-test",
                  "train_records": len(train), "validation_records": len(validation), "test_records": len(test),
                  "train_labelled_pairs": len(train_labels), "validation_labelled_pairs": len(validation_labels),
                  "test_labelled_pairs": len(test_labels), "test_source_counts": dict(source_counts),
                  "results": results, "unavailable_methods": failures, "seconds": stages,
                  "total_seconds": time.perf_counter() - started,
                  "process_peak_rss_bytes": getattr(psutil.Process().memory_info(), "peak_wset", psutil.Process().memory_info().rss),
                  "platform": platform.platform(), "python": platform.python_version(),
                  "frozen_config_sha256": sha(output / "frozen_config.json"),
                  "protocol_sha256": sha(output / "protocol.json"),
                  "limitations": ["Metrics conditional on provided labels; unknown pairs are not negatives",
                                  "Entity-disjoint split differs from the original published paper protocol; scores are not leaderboard-comparable",
                                  "Restaurant/paper records are cross-domain diagnostics, not legal company identities",
                                  "Supplied-pair classification is not candidate retrieval quality",
                                  "Probability outputs are not calibrated for real deployment prevalence",
                                  "Review-budget curves describe known-label recovery, not measured human time savings",
                                  "Insufficient independent groups prevent a reliable bootstrap interval"]}
        save(output / "report.json", report)
        print(json.dumps({"output": str(output), "test_records": len(test), "labelled_test_pairs": len(test_labels),
                          "methods": list(scores), "seconds": report["total_seconds"]}), flush=True)
        return report
    except Exception as error:
        save(output / "failure.json", {"type": type(error).__name__, "reason": str(error), "seconds": stages,
                                       "frozen_config_exists": (output / "frozen_config.json").exists()})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--false-positive-cost", type=float, default=10.0)
    parser.add_argument("--false-negative-cost", type=float, default=1.0)
    parser.add_argument("--bootstrap", type=int, default=400)
    args = parser.parse_args()
    run(args.dataset.resolve(), args.output.resolve(), false_positive_cost=args.false_positive_cost,
        false_negative_cost=args.false_negative_cost, bootstrap=args.bootstrap)


if __name__ == "__main__":
    main()
